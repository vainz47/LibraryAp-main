package com.example.perpus_online;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TambahBukuKaryaIlmiah extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah_buku_karya_ilmiah);
    }
}